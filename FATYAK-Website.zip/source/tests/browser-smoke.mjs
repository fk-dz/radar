import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
const url = process.env.SITE_URL || 'http://localhost:5173';
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(url, { waitUntil: 'networkidle' });
  assert.match(await page.title(), /FATYAK/);
  assert.equal(await page.locator('.planet-label').count(), 8);
  await page.getByRole('button', { name: 'استكشف الحدث', exact: true }).click();
  assert.ok(await page.locator('.local-circumstances').isVisible());
  await page.keyboard.press('Escape');
  await page.locator('.nav-item').filter({ hasText: 'المذنبات' }).click();
  await page.getByRole('textbox', { name: 'البحث في فهرس المذنبات' }).fill('Halley');
  assert.equal(await page.locator('.comet-card').count(), 1);
  await page.locator('.comet-title-button').click();
  await page.locator('.modal').getByRole('button', { name: 'حفظ المذنب', exact: true }).click();
  await page.keyboard.press('Escape');
  await page.locator('.nav-item').filter({ hasText: 'الكسوف والخسوف' }).click();
  await page.getByRole('button', { name: 'الخسوف القمري', exact: true }).click();
  if (await page.getByRole('combobox', { name: 'فلترة الأحداث حسب السنة' }).locator('option[value="2028"]').count()) {
    await page.getByRole('combobox', { name: 'فلترة الأحداث حسب السنة' }).selectOption('2028');
    assert.equal(await page.locator('.event-card').count(), 3);
  }
  await page.locator('.nav-item').filter({ hasText: 'المصادر العلمية' }).click();
  assert.equal(await page.locator('.source-card').count(), 9);
  assert.ok(await page.locator('.news-item').count() > 0);
  await page.keyboard.press('Control+k');
  await page.getByRole('textbox', { name: 'البحث في الكواكب والمذنبات والأحداث' }).fill('المريخ');
  await page.locator('.search-results button').first().click();
  assert.equal(await page.locator('.focus-planet-name h3').innerText(), 'المريخ');
  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await mobile.goto(url, { waitUntil: 'networkidle' });
  await mobile.getByRole('button', { name: 'فتح القائمة' }).click();
  await mobile.locator('.nav-item').filter({ hasText: 'الكسوف والخسوف' }).click();
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  await mobile.locator('.event-title-button').first().click();
  assert.equal(await mobile.locator('.modal').evaluate(el => el.scrollWidth > el.clientWidth), false);
  assert.deepEqual(errors, []);
  console.log('PASS — live pages, real catalog search, local eclipses, bookmarks, navigation, source news, global search and mobile layout.');
} finally { await browser.close(); }
