import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as Astro from 'astronomy-engine';
import { parseComets, parseEclipses, parseNews } from '../scripts/update-data.mjs';
import { PLANETS, planetStates, cometHelio, cometState, localEclipse } from '../src/astronomy.js';
const fixture = name => readFileSync(new URL(`./fixtures/${name}`, import.meta.url), 'utf8');
const location = { lat: 36.7538, lon: 3.0588, height: 10 };
const source = { id: 'nasa-solar-2021', category: 'solar', url: 'https://eclipse.gsfc.nasa.gov/SEdecade/SEdecade2021.html' };
const mpc = parseComets(fixture('MPC-2026-10-11.txt'));

test('MPC: parse verified fixed-width values, full reference and orbital epoch', () => {
  assert.equal(mpc.length, 963);
  const first = mpc[0];
  assert.equal(first.name, 'C/1942 EA (Vaisala)');
  assert.equal(first.q, 1.277586);
  assert.equal(first.e, .934882);
  assert.equal(first.argument, 335.5615);
  assert.equal(first.node, 172.3203);
  assert.equal(first.inclination, 37.8730);
  assert.equal(first.epoch, '2026-10-10');
  assert.equal(first.reference, 'MPEC 2026-K60');
  assert.equal(first.perihelionTT.slice(0, 10), '2028-09-13');
  assert.equal(new Set(mpc.map(c => c.id)).size, mpc.length);
});
test('NASA: parse 2021–2030 solar rows and preserve the TD label', () => {
  const rows = parseEclipses(fixture('NASA-solar-2021.html'), source);
  assert.equal(rows.length, 22);
  const featured = rows.find(e => e.date === '2027-08-02');
  assert.equal(featured.type, 'Total');
  assert.equal(featured.category, 'solar');
  assert.match(featured.mapUrl, /^https:\/\/eclipse\.gsfc\.nasa\.gov\//);
  const approxTD = Date.parse(`${featured.date}T${featured.tdTime}Z`);
  const utc = Date.parse(featured.peakUtcApprox);
  assert.ok(approxTD - utc > 50000 && approxTD - utc < 100000);
});
test('NASA: published seconds rounded to 60 do not invalidate the decade', () => {
  const rows = parseEclipses(fixture('NASA-lunar-2031.html'), { id: 'nasa-lunar-2031', category: 'lunar', url: 'https://eclipse.gsfc.nasa.gov/LEdecade/LEdecade2031.html' });
  assert.equal(rows.length, 23);
  const event = rows.find(e => e.date === '2038-12-11');
  assert.equal(event.tdTime, '17:44:60');
  assert.ok(Number.isFinite(Date.parse(event.peakUtcApprox)));
});
test('Publishers reject error pages instead of fabricating a new catalogue', () => {
  assert.throws(() => parseComets('<html>Access denied</html>'));
  assert.throws(() => parseEclipses('<html>Error</html>', source));
  assert.throws(() => parseNews('<rss/>', { organization: 'NASA', id: 'nasa-news' }));
});
test('All eight planetary coordinates have physical distances and bounded horizons', () => {
  const result = planetStates(new Date('2026-10-11T12:00:00Z'), location);
  assert.equal(result.length, 8);
  for (const planet of result) {
    assert.ok(planet.solarDistance > 0);
    if (planet.id !== 'Earth') {
      assert.ok(planet.distance > 0);
      assert.ok(planet.altitude >= -90 && planet.altitude <= 90);
      assert.ok(planet.azimuth >= 0 && planet.azimuth < 360);
    } else assert.equal(planet.altitude, null);
  }
  assert.ok(result.find(p => p.id === 'Neptune').solarDistance > 29);
});
test('Comet universal solver handles elliptic, parabolic and hyperbolic perihelia', () => {
  const ttDate = '2026-01-01T12:00:00.000Z';
  const t = (Date.parse(ttDate) - Date.parse('2000-01-01T12:00:00Z')) / 86400000;
  const perihelionUTC = Astro.AstroTime.FromTerrestrialTime(t).date;
  for (const e of [.2, .8, .99, 1, 1.01, 1.4]) {
    const c = { q: .8, e, argument: 55, node: 127, inclination: 71, perihelionTT: ttDate };
    const p = cometHelio(c, perihelionUTC);
    assert.ok(Math.abs(Math.hypot(p.x, p.y, p.z) - c.q) < 1e-8, `perihelion q with e=${e}`);
    for (const days of [-400, -10, 10, 400]) {
      const v = cometHelio(c, new Date(perihelionUTC.getTime() + days * 86400000));
      assert.ok(Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z));
      assert.ok(Math.hypot(v.x, v.y, v.z) >= c.q - 1e-9);
    }
  }
});
test('All real MPC records propagate without invalid or negative distances', () => {
  const date = new Date('2026-10-11T12:00:00Z');
  for (const comet of mpc) {
    const state = cometState(comet, date, location);
    assert.ok(state.distance > 0 && Number.isFinite(state.distance), comet.name);
    assert.ok(state.solarDistance >= comet.q - 1e-6, comet.name);
  }
});
test('Local eclipse: Algiers does not falsely claim totality for 2 August 2027', () => {
  const event = parseEclipses(fixture('NASA-solar-2021.html'), source).find(e => e.date === '2027-08-02');
  const local = localEclipse(event, location);
  assert.equal(local.visible, true);
  assert.equal(local.type, 'partial');
  assert.ok(local.obscuration > .99 && local.obscuration < 1);
  assert.ok(local.start < local.peak && local.peak < local.end);
});
