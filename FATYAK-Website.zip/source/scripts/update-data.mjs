import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { load } from 'cheerio';
import { AstroTime } from 'astronomy-engine';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const directory = path.join(root, 'public', 'data');
export const SYNC_INTERVAL = 6 * 60 * 60 * 1000;
const sources = [
  { id: 'nasa-solar-2021', name: 'NASA · Solar eclipses 2021–2030', organization: 'NASA', category: 'solar', url: 'https://eclipse.gsfc.nasa.gov/SEdecade/SEdecade2021.html' },
  { id: 'nasa-solar-2031', name: 'NASA · Solar eclipses 2031–2040', organization: 'NASA', category: 'solar', url: 'https://eclipse.gsfc.nasa.gov/SEdecade/SEdecade2031.html' },
  { id: 'nasa-lunar-2021', name: 'NASA · Lunar eclipses 2021–2030', organization: 'NASA', category: 'lunar', url: 'https://eclipse.gsfc.nasa.gov/LEdecade/LEdecade2021.html' },
  { id: 'nasa-lunar-2031', name: 'NASA · Lunar eclipses 2031–2040', organization: 'NASA', category: 'lunar', url: 'https://eclipse.gsfc.nasa.gov/LEdecade/LEdecade2031.html' },
  { id: 'mpc', name: 'Minor Planet Center · Observable comet elements', organization: 'MPC', category: 'comets', url: 'https://www.minorplanetcenter.net/iau/Ephemerides/Comets/Soft00Cmt.txt' },
  { id: 'nasa-news', name: 'NASA · Latest news RSS', organization: 'NASA', category: 'news', url: 'https://www.nasa.gov/feed/' },
  { id: 'esa-news', name: 'ESA · Space Science RSS', organization: 'ESA', category: 'news', url: 'https://www.esa.int/rssfeed/Our_Activities/Space_Science' },
];
const months = { Jan: 1, Feb: 2, Mar: 3, Apr: 4, May: 5, Jun: 6, Jul: 7, Aug: 8, Sep: 9, Oct: 10, Nov: 11, Dec: 12 };
const normalize = (text) => text.replace(/\s+/g, ' ').trim();

/** Parse NASA's published HTML tables, never a space-data API. Times remain labelled TD. */
export function parseEclipses(html, source) {
  const $ = load(html);
  const events = [];
  $('tr').each((_, row) => {
    const cells = $(row).find('td');
    if (cells.length !== 7) return;
    const values = cells.map((_, cell) => normalize($(cell).text())).get();
    const match = values[0].match(/^(\d{4})\s+([A-Z][a-z]{2})\s+(\d{1,2})$/);
    if (!match || !months[match[2]] || !/^\d{2}:\d{2}:\d{2}$/.test(values[1])) return;
    if (!['Total', 'Partial', 'Annular', 'Hybrid', 'Penumbral'].includes(values[2])) return;
    const date = `${match[1]}-${String(months[match[2]]).padStart(2, '0')}-${match[3].padStart(2, '0')}`;
    // The published canon can round a second to 60 (e.g. 2038-12-11).
    // Date.UTC intentionally normalizes that carry instead of losing the row.
    const [hour, minute, second] = values[1].split(':').map(Number);
    const tdMillis = Date.UTC(Number(match[1]), months[match[2]] - 1, Number(match[3]), hour, minute, second);
    const ttDays = (tdMillis - Date.parse('2000-01-01T12:00:00Z')) / 86400000;
    const approximateUTC = AstroTime.FromTerrestrialTime(ttDays).date.toISOString();
    const mapHref = cells.eq(0).find('a').attr('href');
    const detailHref = cells.eq(2).find('a').attr('href');
    events.push({
      id: `${source.category}-${date}`, date, tdTime: values[1], peakUtcApprox: approximateUTC,
      category: source.category, type: values[2], saros: Number(values[3]),
      magnitude: Number(values[4]), duration: values[5], regions: values[6],
      mapUrl: mapHref ? new URL(mapHref, source.url).href : source.url,
      detailUrl: detailHref ? new URL(detailHref, source.url).href : new URL(`../OH/OH${match[1]}.html`, source.url).href,
      sourceId: source.id, sourceUrl: source.url,
    });
  });
  if (events.length < 10) throw new Error('NASA table structure changed or no valid eclipse rows were received.');
  return events;
}

/** Fixed-width MPC comet format, as documented by the Minor Planet Center. */
export function parseComets(text) {
  const comets = [];
  for (const line of text.split(/\r?\n/)) {
    if (line.length < 103) continue;
    const year = Number(line.slice(14, 18));
    const month = Number(line.slice(19, 21));
    const day = Number(line.slice(22, 29));
    const q = Number(line.slice(30, 39));
    const e = Number(line.slice(41, 49));
    const argument = Number(line.slice(51, 59));
    const node = Number(line.slice(61, 69));
    const inclination = Number(line.slice(71, 79));
    const name = line.slice(102, 158).trim();
    if (!name || !Number.isFinite(q) || q <= 0 || e < 0 || !Number.isFinite(e) || year < 1500 || month < 1 || month > 12 || day < 1 || day >= 32) continue;
    const perihelionMillis = Date.UTC(year, month - 1, 1) + (day - 1) * 86400000;
    const ttDays = (perihelionMillis - Date.parse('2000-01-01T12:00:00Z')) / 86400000;
    const epochRaw = line.slice(81, 89).trim();
    const hText = line.slice(91, 95).trim();
    const slopeText = line.slice(96, 100).trim();
    comets.push({
      id: line.slice(0, 12).trim(), name, q, e, argument, node, inclination,
      perihelionTT: new Date(perihelionMillis).toISOString(),
      perihelionUTC: AstroTime.FromTerrestrialTime(ttDays).date.toISOString(),
      epoch: /^\d{8}$/.test(epochRaw) ? `${epochRaw.slice(0, 4)}-${epochRaw.slice(4, 6)}-${epochRaw.slice(6, 8)}` : null,
      absoluteMagnitude: hText && Number.isFinite(Number(hText)) ? Number(hText) : null,
      slope: slopeText && Number.isFinite(Number(slopeText)) ? Number(slopeText) : null,
      reference: line.slice(159).trim(),
    });
  }
  if (comets.length < 50) throw new Error('MPC returned too few valid orbital records. Existing data has been preserved.');
  return comets;
}

export function parseNews(xml, source) {
  const $ = load(xml, { xmlMode: true });
  const result = [];
  $('item').slice(0, 5).each((_, item) => {
    const title = $(item).find('title').first().text().trim();
    const url = $(item).find('link').first().text().trim();
    const rawDate = $(item).find('pubDate').first().text().trim();
    if (title && /^https:\/\//.test(url)) result.push({ title, url, publishedAt: Number.isFinite(Date.parse(rawDate)) ? new Date(rawDate).toISOString() : null, organization: source.organization, sourceId: source.id });
  });
  if (!result.length) throw new Error('No valid RSS news entries.');
  return result;
}

async function readJson(filename, fallback) {
  try { return JSON.parse(await fs.readFile(path.join(directory, filename), 'utf8')); } catch { return fallback; }
}
async function writeAtomic(filename, value) {
  const text = JSON.stringify(value);
  // Published static files and a build-time offline snapshot are kept identical.
  // Importing the snapshot from src avoids Vite's public-directory import warnings.
  await Promise.all([directory, path.join(root, 'src', 'data')].map(async folder => {
    await fs.mkdir(folder, { recursive: true });
    const target = path.join(folder, filename);
    await fs.writeFile(`${target}.tmp`, text);
    await fs.rename(`${target}.tmp`, target);
  }));
}
let running = null;
export function updateData() {
  if (running) return running;
  running = performUpdate().finally(() => { running = null; });
  return running;
}
async function performUpdate() {
  await fs.mkdir(directory, { recursive: true });
  const [oldCatalogue, oldEclipses, oldNews, oldStatus] = await Promise.all([
    readJson('comets.json', { records: [] }), readJson('eclipses.json', { records: [] }),
    readJson('news.json', { records: [] }), readJson('status.json', { sources: [] }),
  ]);
  const attemptedAt = new Date().toISOString();
  const sourceRecords = [];
  let comets = oldCatalogue.records;
  let eclipses = [...oldEclipses.records];
  let news = [...oldNews.records];
  let cometFetchedAt = oldCatalogue.fetchedAt || null;
  await Promise.all(sources.map(async (source) => {
    const previous = oldStatus.sources.find(s => s.id === source.id);
    try {
      const response = await fetch(source.url, {
        signal: AbortSignal.timeout(18000),
        headers: { 'User-Agent': 'FATYAK-Observatory/1.0 (educational; public tables; 6-hour cache)', Accept: source.category === 'comets' ? 'text/plain' : '*/*' },
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const text = await response.text();
      let records;
      if (source.category === 'comets') { records = parseComets(text); comets = records; cometFetchedAt = attemptedAt; }
      else if (source.category === 'news') { records = parseNews(text, source); news = [...news.filter(n => n.sourceId !== source.id), ...records]; }
      else { records = parseEclipses(text, source); eclipses = [...eclipses.filter(e => e.sourceId !== source.id), ...records]; }
      sourceRecords.push({ ...source, state: 'synced', fetchedAt: attemptedAt, attemptedAt, recordCount: records.length, error: null });
      console.log(`[data] ${source.id}: ${records.length} verified records downloaded`);
    } catch (error) {
      const message = String(error?.message || error);
      sourceRecords.push({ ...source, state: previous?.fetchedAt ? 'cached' : 'unavailable', fetchedAt: previous?.fetchedAt || null, attemptedAt, recordCount: previous?.recordCount || 0, error: message });
      console.warn(`[data] ${source.id}: ${message}; keeping the last verified copy`);
    }
  }));
  eclipses.sort((a, b) => a.peakUtcApprox.localeCompare(b.peakUtcApprox));
  news.sort((a, b) => (b.publishedAt || '').localeCompare(a.publishedAt || ''));
  sourceRecords.sort((a, b) => sources.findIndex(s => s.id === a.id) - sources.findIndex(s => s.id === b.id));
  const status = { attemptedAt, nextScheduledAt: new Date(Date.parse(attemptedAt) + SYNC_INTERVAL).toISOString(), intervalHours: 6, sources: sourceRecords, externalAPIs: false, method: 'Published NASA HTML tables, MPC plain-text orbital elements, NASA/ESA RSS; no API keys or external data APIs.' };
  await Promise.all([
    writeAtomic('comets.json', { source: sources.find(s => s.category === 'comets').url, fetchedAt: cometFetchedAt, records: comets }),
    writeAtomic('eclipses.json', { fetchedAt: attemptedAt, records: eclipses, timeStandard: 'TD (Terrestrial Dynamical Time), with approximate UTC conversion via Astronomy Engine' }),
    writeAtomic('news.json', { fetchedAt: attemptedAt, records: news }),
  ]);
  await writeAtomic('status.json', status);
  return status;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const status = await updateData();
  const successes = status.sources.filter(s => s.state === 'synced').length;
  console.log(`[data] Finished: ${successes}/${status.sources.length} sources synchronized.`);
  if (!successes) process.exitCode = 1;
}
