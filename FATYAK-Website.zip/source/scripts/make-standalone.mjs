import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const folder = path.join(root, 'dist');
let html = await fs.readFile(path.join(folder, 'index.html'), 'utf8');
const assets = [];
for (const match of html.matchAll(/<script[^>]+src="([^"]+)"[^>]*><\/script>/g)) {
  const relative = match[1].replace(/^\.\//, '').replace(/^\//, '');
  let text = await fs.readFile(path.join(folder, relative), 'utf8');
  text = text.replace(/<\/script/gi, '<\\/script');
  assets.push({ old: match[0], replacement: `<script type="module">${text}</script>` });
}
for (const match of html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*>/g)) {
  const href = match[0].match(/href="([^"]+)"/)?.[1];
  if (!href) continue;
  const text = await fs.readFile(path.join(folder, href.replace(/^\.\//, '').replace(/^\//, '')), 'utf8');
  assets.push({ old: match[0], replacement: `<style>${text.replace(/<\/style/gi, '<\\/style')}</style>` });
}
// A function replacement preserves literal $& / $' sequences in bundled React code.
for (const { old, replacement } of assets) html = html.replace(old, () => replacement);
const logo = await fs.readFile(path.join(root, 'public/logo-mark.svg'));
html = html.replace(/href="(?:\.\/|\/)?logo-mark\.svg"/, `href="data:image/svg+xml;base64,${logo.toString('base64')}"`);
const notices = { 'FATYAK MIT': await fs.readFile(path.join(root, 'LICENSE'), 'utf8') };
for (const name of await fs.readdir(path.join(root, 'licenses'))) {
  if (name.endsWith('.txt')) notices[name] = await fs.readFile(path.join(root, 'licenses', name), 'utf8');
}
const licenseData = JSON.stringify(notices).replace(/<\/script/gi, '<\\/script');
html = html.replace('</head>', () => `<script>window.FATYAK_STANDALONE=true;</script><script type="application/json" id="fatyak-license-notices">${licenseData}</script></head>`);
html = html.replace('<html lang="ar" dir="rtl">', '<html lang="ar" dir="rtl" data-fatyak-edition="standalone">');
if (/<script[^>]+src=|<link[^>]+rel="stylesheet"/.test(html)) throw new Error('External code resources remain: refusing to create an incomplete standalone file.');
const destination = process.argv[2] ? path.resolve(process.cwd(), process.argv[2]) : path.join(root, 'FATYAK-Observatory.html');
await fs.writeFile(destination, html);
console.log(`Standalone website: ${destination} (${(Buffer.byteLength(html) / 1024 / 1024).toFixed(2)} MB). All graphics, fonts, engine and snapshots are embedded.`);
