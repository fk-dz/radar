import * as Astro from 'astronomy-engine';

export const AU_KM = 149597870.7;
export const PLANETS = [
  { id: 'Mercury', name: 'عطارد', english: 'Mercury', color: '#acaaa2', radius: 2439.7, period: 87.969, kind: 'كوكب صخري', description: 'أقرب الكواكب إلى الشمس وأصغرها. تعبر سماءه الشمس ببطء، بينما ينجز مداره في 88 يومًا أرضيًا.' },
  { id: 'Venus', name: 'الزهرة', english: 'Venus', color: '#dfc197', radius: 6051.8, period: 224.701, kind: 'كوكب صخري', description: 'كوكب تحجبه سحب كثيفة، وهو أشد الكواكب حرارة. يبدو لامعًا قرب الأفق قبل الشروق أو بعد الغروب.' },
  { id: 'Earth', name: 'الأرض', english: 'Earth', color: '#79b9f3', radius: 6371, period: 365.256, kind: 'موطننا الكوني', description: 'نقطة انطلاق الرصد، والكوكب الوحيد المعروف باحتضان الحياة. تدور الأرض حول الشمس كل سنة تقريبًا.' },
  { id: 'Mars', name: 'المريخ', english: 'Mars', color: '#e88c6d', radius: 3389.5, period: 686.98, kind: 'كوكب صخري', description: 'الكوكب الأحمر، عالم من الصحارى والفوهات. تستغرق سنته نحو 687 يومًا أرضيًا، وتحوم حوله بعثات علمية عديدة.' },
  { id: 'Jupiter', name: 'المشتري', english: 'Jupiter', color: '#d9b28b', radius: 69911, period: 4332.59, kind: 'عملاق غازي', description: 'أكبر كواكب مجموعتنا الشمسية. عالم من أحزمة السحب والعواصف الهائلة، وأربعة أقمار كبيرة يمكن رصدها بمنظار.' },
  { id: 'Saturn', name: 'زحل', english: 'Saturn', color: '#e0c895', radius: 58232, period: 10759.22, kind: 'عملاق غازي', description: 'تحيط به حلقات من الجليد والصخر. كثافته المتوسطة أقل من كثافة الماء، ويستغرق مداره قرابة 29 سنة أرضية.' },
  { id: 'Uranus', name: 'أورانوس', english: 'Uranus', color: '#a2ddd5', radius: 25362, period: 30688.5, kind: 'عملاق جليدي', description: 'يدور هذا العملاق الجليدي على جانبه تقريبًا. يمنحه الميثان في غلافه الجوي لونًا أزرق مخضرًا.' },
  { id: 'Neptune', name: 'نبتون', english: 'Neptune', color: '#698ee8', radius: 24622, period: 60182, kind: 'عملاق جليدي', description: 'أبعد كواكب النظام الشمسي، وتحيط به رياح شديدة. يحتاج ضوء الشمس إلى أكثر من أربع ساعات للوصول إليه.' },
];
export const CONSTELLATIONS = { Ari: 'الحمل', Tau: 'الثور', Gem: 'التوأمان', Cnc: 'السرطان', Leo: 'الأسد', Vir: 'العذراء', Lib: 'الميزان', Sco: 'العقرب', Sgr: 'القوس', Cap: 'الجدي', Aqr: 'الدلو', Psc: 'الحوت', Oph: 'الحواء', Cet: 'قيطس', Peg: 'الفرس الأعظم', And: 'المرأة المسلسلة', Per: 'برشاوس', Aur: 'ممسك الأعنة', Ori: 'الجبار', UMa: 'الدب الأكبر', UMi: 'الدب الأصغر', Dra: 'التنين', Cyg: 'الدجاجة', Cas: 'ذات الكرسي', Lyr: 'القيثارة', Aql: 'العقاب' };
export const ECLIPSE_TYPES = { Total: 'كلي', Partial: 'جزئي', Annular: 'حلقي', Hybrid: 'هجين', Penumbral: 'شبه ظلي' };
export function eclipseName(event) { return `${event.category === 'solar' ? 'كسوف شمسي' : 'خسوف قمري'} ${ECLIPSE_TYPES[event.type] || event.type}`; }
export function observer(location) { return new Astro.Observer(location.lat, location.lon, location.height || 0); }
export function planetStates(date, location) {
  const obs = observer(location);
  return PLANETS.map(planet => {
    const helio = Astro.HelioVector(planet.id, date);
    const ecliptic = Astro.RotateVector(Astro.Rotation_EQJ_ECL(), helio);
    const solarDistance = Math.hypot(helio.x, helio.y, helio.z);
    if (planet.id === 'Earth') return { ...planet, helio: ecliptic, solarDistance, distance: 0, altitude: null, azimuth: null, ra: null, dec: null, magnitude: null, constellation: null };
    const eq = Astro.Equator(planet.id, date, obs, true, true);
    const hor = Astro.Horizon(date, obs, eq.ra, eq.dec, 'normal');
    const eqj = Astro.Equator(planet.id, date, obs, false, true);
    const constellation = Astro.Constellation(eqj.ra, eqj.dec);
    const illumination = Astro.Illumination(planet.id, date);
    return { ...planet, helio: ecliptic, solarDistance, distance: eq.dist, altitude: hor.altitude, azimuth: hor.azimuth, ra: eq.ra, dec: eq.dec, magnitude: illumination.mag, constellation: CONSTELLATIONS[constellation.symbol] || constellation.name, lightMinutes: eq.dist * AU_KM / 299792.458 / 60 };
  });
}
export function skyExtras(date, location) {
  const obs = observer(location);
  return ['Sun', 'Moon'].map(id => {
    const eq = Astro.Equator(id, date, obs, true, true);
    const hor = Astro.Horizon(date, obs, eq.ra, eq.dec, 'normal');
    return { id, name: id === 'Sun' ? 'الشمس' : 'القمر', color: id === 'Sun' ? '#f4d177' : '#ced4d9', distance: eq.dist, altitude: hor.altitude, azimuth: hor.azimuth, ra: eq.ra, dec: eq.dec };
  });
}
export function risesAndSets(id, date, location) {
  if (id === 'Earth') return { rise: null, set: null };
  const obs = observer(location);
  try { return { rise: Astro.SearchRiseSet(id, obs, 1, date, 2)?.date || null, set: Astro.SearchRiseSet(id, obs, -1, date, 2)?.date || null }; }
  catch { return { rise: null, set: null }; }
}

export function planetOrbit(id, date, samples = 100) {
  const period = PLANETS.find(p => p.id === id).period;
  const rotation = Astro.Rotation_EQJ_ECL();
  return Array.from({ length: samples + 1 }, (_, n) => {
    const sampleDate = new Date(date.getTime() + (n / samples - 0.5) * period * 86400000);
    return Astro.RotateVector(rotation, Astro.HelioVector(id, sampleDate));
  });
}

const K = 0.01720209895;
const DEG = Math.PI / 180;
const DAY = 86400000;
const J2000 = Date.parse('2000-01-01T12:00:00Z');
function stumpff(z) {
  if (Math.abs(z) < 1e-6) return { C: 0.5 - z / 24 + z * z / 720 - z ** 3 / 40320, S: 1 / 6 - z / 120 + z * z / 5040 - z ** 3 / 362880 };
  if (z > 0) { const r = Math.sqrt(z); return { C: (1 - Math.cos(r)) / z, S: (r - Math.sin(r)) / r ** 3 }; }
  const r = Math.sqrt(-z);
  if (r > 700) return { C: Infinity, S: Infinity };
  return { C: (Math.cosh(r) - 1) / (-z), S: (Math.sinh(r) - r) / r ** 3 };
}
function rotateOrbit(x, y, comet) {
  const omega = comet.argument * DEG, node = comet.node * DEG, inc = comet.inclination * DEG;
  const xp = x * Math.cos(omega) - y * Math.sin(omega);
  const yp = x * Math.sin(omega) + y * Math.cos(omega);
  return { x: xp * Math.cos(node) - yp * Math.cos(inc) * Math.sin(node), y: xp * Math.sin(node) + yp * Math.cos(inc) * Math.cos(node), z: yp * Math.sin(inc) };
}
/** Two-body propagation of MPC elements. Supports elliptic, parabolic and hyperbolic orbits.
 * It is deliberately labelled approximate: planetary perturbations/non-gravitational forces
 * are not integrated. It is not a telescope-grade astrometric ephemeris.
 */
export function cometHelio(comet, date) {
  const t = Astro.MakeTime(date);
  const perihelionTT = (Date.parse(comet.perihelionTT) - J2000) / DAY;
  const dt = t.tt - perihelionTT;
  const { q, e } = comet;
  let x, y;
  if (e < 0.98) {
    const a = q / (1 - e), n = K / a ** 1.5;
    const mean = ((n * dt + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
    let E = mean;
    for (let i = 0; i < 25; i++) { const delta = (E - e * Math.sin(E) - mean) / (1 - e * Math.cos(E)); E -= delta; if (Math.abs(delta) < 1e-12) break; }
    x = a * (Math.cos(E) - e); y = a * Math.sqrt(1 - e * e) * Math.sin(E);
  } else if (e > 1.02) {
    const a = q / (e - 1), M = K * dt / a ** 1.5;
    let H = Math.asinh(M / e);
    for (let i = 0; i < 40; i++) { const delta = (e * Math.sinh(H) - H - M) / (e * Math.cosh(H) - 1); H -= Math.max(-2, Math.min(2, delta)); if (Math.abs(delta) < 1e-12) break; }
    x = a * (e - Math.cosh(H)); y = a * Math.sqrt(e * e - 1) * Math.sinh(H);
  } else {
    const alpha = (1 - e) / q, target = K * Math.abs(dt);
    let lo = 0, hi = Math.max(1, target / q);
    for (let i = 0; i < 65; i++) {
      const chi = (lo + hi) / 2, { S } = stumpff(alpha * chi * chi);
      const value = q * chi + e * chi ** 3 * S;
      if (value > target) hi = chi; else lo = chi;
    }
    const chi = (lo + hi) / 2 * Math.sign(dt);
    const { C, S } = stumpff(alpha * chi * chi);
    x = q - chi * chi * C;
    y = (dt - chi ** 3 * S / K) * K * Math.sqrt((1 + e) / q);
  }
  return rotateOrbit(x, y, comet);
}
export function cometState(comet, date, location, full = false) {
  const earthEq = Astro.HelioVector('Earth', date);
  const earth = Astro.RotateVector(Astro.Rotation_EQJ_ECL(), earthEq);
  let helio = cometHelio(comet, date);
  let dx = helio.x - earth.x, dy = helio.y - earth.y, dz = helio.z - earth.z;
  let distance = Math.hypot(dx, dy, dz);
  // One light-time correction, adequate for the explicitly approximate model.
  if (full) {
    helio = cometHelio(comet, new Date(date.getTime() - distance / Astro.C_AUDAY * DAY));
    dx = helio.x - earth.x; dy = helio.y - earth.y; dz = helio.z - earth.z;
    distance = Math.hypot(dx, dy, dz);
  }
  const solarDistance = Math.hypot(helio.x, helio.y, helio.z);
  const magnitude = comet.absoluteMagnitude != null && comet.slope != null ? comet.absoluteMagnitude + 5 * Math.log10(distance) + 2.5 * comet.slope * Math.log10(solarDistance) : null;
  const result = { ...comet, helio, distance, solarDistance, magnitude };
  if (full) {
    const obs = observer(location);
    const vec = new Astro.Vector(dx, dy, dz, date);
    const eqj = Astro.RotateVector(Astro.Rotation_ECL_EQJ(), vec);
    const obsVector = Astro.ObserverVector(date, obs, false);
    const topo = new Astro.Vector(eqj.x - obsVector.x, eqj.y - obsVector.y, eqj.z - obsVector.z, date);
    const eqd = Astro.RotateVector(Astro.Rotation_EQJ_EQD(date), topo);
    const equatorial = Astro.EquatorFromVector(eqd);
    const horizontal = Astro.Horizon(date, obs, equatorial.ra, equatorial.dec, 'normal');
    Object.assign(result, { altitude: horizontal.altitude, azimuth: horizontal.azimuth, ra: equatorial.ra, dec: equatorial.dec });
  }
  return result;
}
export function cometOrbit(comet, samples = 140) {
  const maxAngle = comet.e >= 1 ? Math.acos(-1 / comet.e) - 0.02 : Math.PI;
  return Array.from({ length: samples + 1 }, (_, i) => {
    const v = -maxAngle + 2 * maxAngle * i / samples;
    const r = comet.q * (1 + comet.e) / (1 + comet.e * Math.cos(v));
    return rotateOrbit(r * Math.cos(v), r * Math.sin(v), comet);
  });
}
export function localEclipse(event, location) {
  const start = new Date(Date.parse(`${event.date}T00:00:00Z`) - DAY);
  const obs = observer(location);
  if (event.category === 'solar') {
    try {
      const local = Astro.SearchLocalSolarEclipse(start, obs);
      if (Math.abs(local.peak.time.date.getTime() - Date.parse(event.peakUtcApprox)) > DAY) return { visible: false };
      return { visible: true, type: local.kind, obscuration: local.obscuration, peak: local.peak.time.date, altitude: local.peak.altitude, start: local.partial_begin.time.date, end: local.partial_end.time.date };
    } catch { return null; }
  }
  const peak = new Date(event.peakUtcApprox);
  const eq = Astro.Equator('Moon', peak, obs, true, true);
  const h = Astro.Horizon(peak, obs, eq.ra, eq.dec, 'normal');
  return { visibleAtPeak: h.altitude > 0, altitude: h.altitude, peak };
}
export const formatNumber = (value, decimals = 1) => Number.isFinite(value) ? new Intl.NumberFormat('en-US', { maximumFractionDigits: decimals, minimumFractionDigits: decimals }).format(value) : '—';
export const dateLabel = (value, options = {}) => new Date(value).toLocaleDateString('ar-DZ', { day: 'numeric', month: 'long', year: 'numeric', numberingSystem: 'latn', ...options });
export const timeLabel = (value) => value ? new Date(value).toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit', numberingSystem: 'latn' }) : '—';
