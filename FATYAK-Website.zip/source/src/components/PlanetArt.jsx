import { useId } from 'react';

export default function PlanetArt({ id = 'Jupiter', size = 160, className = '' }) {
  const uid = useId().replace(/:/g, '');
  const clip = `clip-${uid}`, shade = `shade-${uid}`, sphere = `sphere-${uid}`;
  const palettes = { Mercury: ['#beb8aa', '#7d7b72', '#464740'], Venus: ['#f3ddb3', '#d2aa73', '#8d6d3d'], Earth: ['#9bccec', '#3e91b8', '#17485e'], Mars: ['#e9a474', '#b96644', '#693425'], Jupiter: ['#eadbc6', '#c3a082', '#705849'], Saturn: ['#eee1b4', '#c2ad7c', '#806b43'], Uranus: ['#c1f2e7', '#8ecac7', '#457e8f'], Neptune: ['#9aacfc', '#416ed0', '#213b88'], Moon: ['#dedfd7', '#8b8e89', '#444c4a'] };
  const colors = palettes[id] || palettes.Moon;
  const bands = id === 'Jupiter' ? [[37, 13, '#c5a28c'], [52, 10, '#f1e2ce'], [66, 17, '#b58a71'], [83, 8, '#edddc7'], [96, 16, '#b7967c'], [115, 9, '#d8bda5'], [128, 18, '#aa8368'], [149, 14, '#eee0c4']] : id === 'Saturn' || id === 'Venus' ? [[45, 13, colors[1]], [73, 5, colors[0]], [87, 9, colors[1]], [106, 12, colors[0]], [128, 8, colors[1]], [145, 6, colors[0]]] : [];
  return <svg className={`planet-art ${className}`} width={size} height={size} viewBox="0 0 200 200" role="img" aria-label={`رسم توضيحي ${id}`}>
    <defs><clipPath id={clip}><circle cx="100" cy="100" r={id === 'Saturn' ? 58 : 77}/></clipPath><radialGradient id={sphere} cx="32%" cy="25%" r="80%"><stop stopColor={colors[0]}/><stop offset=".55" stopColor={colors[1]}/><stop offset="1" stopColor={colors[2]}/></radialGradient><radialGradient id={shade} cx="26%" cy="25%" r="82%"><stop offset=".1" stopColor="#020808" stopOpacity="0"/><stop offset=".55" stopColor="#020808" stopOpacity=".09"/><stop offset=".86" stopColor="#020808" stopOpacity=".68"/><stop offset="1" stopColor="#020808" stopOpacity=".95"/></radialGradient></defs>
    {id === 'Saturn' && <ellipse cx="100" cy="106" rx="98" ry="28" fill="none" stroke="#c5b38b" strokeWidth="16" opacity=".7" transform="rotate(-22 100 106)"/>}
    <circle cx="100" cy="100" r={id === 'Saturn' ? 58 : 77} fill={`url(#${sphere})`}/>
    <g clipPath={`url(#${clip})`}>{bands.map(([y, h, fill], i) => <path key={i} d={`M0 ${y} Q95 ${y - 8} 200 ${y + 3} L200 ${y + h} Q95 ${y + h - 5} 0 ${y + h}Z`} fill={fill} opacity={id === 'Jupiter' ? '.88' : '.3'}/>)}
      {id === 'Jupiter' && <><ellipse cx="132" cy="117" rx="18" ry="8" fill="#a76853" transform="rotate(5 132 117)"/><ellipse cx="132" cy="117" rx="12" ry="4" fill="#c48265"/><path d="M18 64q42 13 66 3t80 3M0 137q72-14 103-2t100-3" stroke="#e6c8ab" opacity=".4" fill="none" strokeWidth="2"/></>}
      {id === 'Earth' && <><path d="M42 44l17-5 18 9 5 15-8 12-15 3-6 11-13-4-10-18zM72 88l18 7 8 27-9 12-5 27-10-5-3-21-9-17zM108 45l24-8 38 21-5 22-27 11-18-9-8-13-16-5zM118 93l20 3 8 20-17 29-8-14-6-26zM157 132l15 9-4 9-16-4z" fill="#86a77b"/><path d="M34 83q40-14 75 3t66-9M23 118q52-5 82 4t69-2" stroke="#f1faf9" opacity=".48" strokeWidth="6" fill="none"/><path d="M60 33q33-16 74 7" stroke="#eff5ed" strokeWidth="14" fill="none"/></>}
      {['Mercury', 'Mars', 'Moon'].includes(id) && Array.from({ length: 16 }, (_, i) => <circle key={i} cx={35 + (i * 37) % 126} cy={32 + (i * 47) % 130} r={3 + i % 6} fill={i % 2 ? '#2f2522' : '#f6dcc2'} opacity=".12"/>)}
      {id === 'Mars' && <path d="M42 117l19-21 28 4 23-20 23 3 12 19-10 7-29-2-23 12-22-7z" fill="#533329" opacity=".3"/>}
      <circle cx="100" cy="100" r={id === 'Saturn' ? 58 : 77} fill={`url(#${shade})`}/>
    </g>
    {id === 'Saturn' && <path d="M2 106C2 143 198 143 198 106" transform="rotate(-22 100 106)" fill="none" stroke="#c9b78b" strokeWidth="11" opacity=".8"/>}
  </svg>;
}
