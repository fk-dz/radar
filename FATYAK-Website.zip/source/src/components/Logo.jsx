export function LogoMark({ size = 40 }) {
  return <svg width={size} height={size} viewBox="0 0 80 80" fill="none" aria-hidden="true"><rect width="80" height="80" rx="23" fill="currentColor" opacity=".035"/><ellipse cx="40" cy="40" rx="31" ry="16" transform="rotate(-39 40 40)" stroke="var(--accent)" strokeWidth="2.6"/><path d="M30 23h25l-3 8H39v8h12l-3 8h-9v13h-9z" fill="var(--text)"/><circle cx="65" cy="23" r="5" fill="var(--accent)"/><circle cx="13" cy="57" r="2" fill="var(--accent)"/></svg>;
}
export default function Logo({ compact = false }) {
  return <div className="brand" dir="ltr"><LogoMark size={43}/>{!compact && <div><strong>FATYAK<span className="brand-dot">.</span></strong><small>SPACE OBSERVATORY</small></div>}</div>;
}
