import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

export default function Modal({ title, children, onClose, wide = false, className = '' }) {
  const dialog = useRef(null);
  useEffect(() => {
    const previous = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const initialFocus = dialog.current?.querySelector('input[autofocus], .search-dialog-input input') || dialog.current?.querySelector('button, input, select, [tabindex="0"]');
    initialFocus?.focus();
    function keyboard(event) {
      if (event.key === 'Escape') { event.preventDefault(); onClose(); }
      if (event.key === 'Tab') {
        const focusable = [...dialog.current.querySelectorAll('button, a[href], input, select, textarea, [tabindex="0"]')].filter(element => !element.disabled && element.offsetParent !== null);
        const first = focusable[0], last = focusable.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    }
    document.addEventListener('keydown', keyboard);
    return () => { document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', keyboard); previous?.focus(); };
  }, [onClose]);
  return createPortal(<div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><section ref={dialog} role="dialog" aria-modal="true" aria-label={title} className={`modal ${wide ? 'wide' : ''} ${className}`}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" aria-label="إغلاق النافذة" onClick={onClose}><X size={19}/></button></div><div className="modal-body">{children}</div></section></div>, document.body);
}
