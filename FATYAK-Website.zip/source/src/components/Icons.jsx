export function Comet({ size = 24, strokeWidth = 1.7, ...props }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="m8 12 11-10M12 16l10-8M10 14l12-9M5 9l8-7"/><circle cx="7" cy="17" r="4"/><path d="m7 1 .5 1.5L9 3l-1.5.5L7 5l-.5-1.5L5 3l1.5-.5Z" strokeWidth="1.1"/></svg>;
}
