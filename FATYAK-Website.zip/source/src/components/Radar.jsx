import { useMemo, useState } from 'react';
import { Maximize2, Minus, Plus, RotateCcw, Orbit, Compass, Eye, EyeOff } from 'lucide-react';
import { PLANETS, planetOrbit, cometOrbit, skyExtras, formatNumber } from '../astronomy.js';

const CX = 350, CY = 234, SKY_R = 181;
export function radarPoint(vector) {
  const actual = Math.hypot(vector.x, vector.y);
  const radius = actual < 0.001 ? 0 : 22 + 192 * Math.log1p(actual * 2) / Math.log(61);
  const angle = Math.atan2(vector.y, vector.x);
  return { x: CX + Math.cos(angle) * radius, y: CY - Math.sin(angle) * radius };
}
const pathFrom = (points) => points.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' ');
const polarPoint = (p) => { const r = (90 - p.altitude) / 90 * SKY_R; const az = p.azimuth * Math.PI / 180; return { x: CX + Math.sin(az) * r, y: CY - Math.cos(az) * r }; };

export default function Radar({ planets, comets = [], date, location, selectedId, onSelect, controls, expanded = false, onExpand }) {
  const [mode, setMode] = useState('solar');
  const [zoom, setZoom] = useState(1);
  const [showComets, setShowComets] = useState(false);
  const orbitStamp = `${date.getUTCFullYear()}-${date.getUTCMonth()}`;
  const orbits = useMemo(() => PLANETS.map(p => ({ id: p.id, points: planetOrbit(p.id, date).map(radarPoint) })), [orbitStamp]);
  const cometPaths = useMemo(() => comets.slice(0, 3).map(c => ({ id: c.id, points: cometOrbit(c).filter(v => Math.hypot(v.x, v.y) < 60).map(radarPoint) })), [comets]);
  const extras = useMemo(() => skyExtras(date, location), [date, location]);
  const sunAltitude = extras.find(p => p.id === 'Sun')?.altitude || 0;
  const skyBodies = [...planets.filter(p => p.id !== 'Earth'), ...extras].filter(p => p.altitude >= 0);
  return <section className={`panel radar-panel ${expanded ? 'expanded-radar' : ''}`}>
    <div className="panel-heading"><div className="heading-icon"><Orbit size={18}/><h2>{mode === 'solar' ? 'رادار النظام الشمسي' : 'سماء موقعك الآن'}</h2><span className="subtle-tag"><span className="status-dot"/>حساب محلي</span></div><div className="panel-actions">{onExpand && <button className="icon-button" aria-label="تكبير الرادار" title="تكبير الرادار" onClick={onExpand}><Maximize2 size={16}/></button>}</div></div>
    <div className="radar-toolbar"><div className="segmented"><button className={mode === 'solar' ? 'active' : ''} onClick={() => { setMode('solar'); setZoom(1); }}><Orbit size={14}/>المدارات</button><button className={mode === 'sky' ? 'active' : ''} onClick={() => { setMode('sky'); setZoom(1); }}><Compass size={14}/>سماء موقعك</button></div><span className="radar-time mono" dir="ltr">{date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' })}<span> · </span>{date.toISOString().slice(11, 16)} UTC</span></div>
    <div className="radar-canvas">
      <div className="radar-corner"><span className="micro-label">{mode === 'solar' ? 'HELIOCENTRIC VIEW' : 'LOCAL HORIZON'}</span><span>{mode === 'solar' ? 'مركز الرصد: الشمس' : `${location.name} · ${sunAltitude > -6 ? 'السماء نهارية' : 'السماء ليلية'}`}</span></div>
      <svg className="radar-svg" viewBox="0 0 720 470" role="img" aria-label={mode === 'solar' ? 'خريطة تفاعلية لمواقع الكواكب المحسوبة حول الشمس' : 'خريطة أجرام السماء فوق الأفق من موقع الرصد'}>
        <defs><radialGradient id="radarGlow"><stop stopColor="#a8dc73" stopOpacity=".04"/><stop offset="1" stopColor="#101719" stopOpacity="0"/></radialGradient><radialGradient id="sunFill"><stop stopColor="#fff4c1"/><stop offset=".4" stopColor="#fbd88c"/><stop offset="1" stopColor="#c98640"/></radialGradient>{PLANETS.map(p => <radialGradient key={p.id} id={`dot-${p.id}`} cx="30%" cy="25%"><stop stopColor="#f0e9d9"/><stop offset=".3" stopColor={p.color}/><stop offset="1" stopColor="#172122"/></radialGradient>)}</defs>
        <rect width="720" height="470" fill="url(#radarGlow)"/>
        {Array.from({ length: 73 }, (_, i) => <circle key={i} cx={(i * 193 + 29) % 720} cy={(i * 127 + 31) % 470} r={i % 8 === 0 ? 1.1 : .55} fill="#a9c0bf" opacity={.1 + (i % 3) * .065}/>)}
        <g className="chart-crosshair"><path d={`M${CX} 14V456M45 ${CY}H671`} stroke="var(--line)" strokeDasharray="2 7"/><path d={`M${CX - 9} 16h18M${CX - 9} 452h18M47 ${CY - 9}v18M670 ${CY - 9}v18`} stroke="var(--line)"/></g>
        <g transform={`translate(${CX} ${CY}) scale(${zoom}) translate(${-CX} ${-CY})`}>
          {mode === 'solar' ? <>
            {orbits.map(o => <path key={o.id} d={pathFrom(o.points)} fill="none" stroke={o.id === selectedId ? 'var(--accent)' : 'var(--orbit-line)'} strokeWidth={o.id === selectedId ? 1.15 : .9} opacity={o.id === selectedId ? .34 : 1}/>)}
            {showComets && cometPaths.map((p, i) => <path key={p.id} d={pathFrom(p.points)} fill="none" stroke={['#a9d4cd', '#adc6e9', '#ddbc87'][i]} opacity=".27" strokeWidth="1" strokeDasharray="3 6"/>)}
            <circle cx={CX} cy={CY} r="24" fill="#edc369" opacity=".025"/><circle cx={CX} cy={CY} r="17" fill="#edc369" opacity=".06"/><circle cx={CX} cy={CY} r="10.5" fill="url(#sunFill)"/><text x={CX} y={CY + 29} className="sun-label" textAnchor="middle">الشمس</text>
            {planets.map(p => { const point = radarPoint(p.helio); const selected = p.id === selectedId; const left = point.x < CX; return <g key={p.id} className="radar-object" transform={`translate(${point.x} ${point.y})`} role="button" tabIndex="0" aria-label={`تحديد ${p.name}`} onClick={() => onSelect(p.id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(p.id); } }}><title>{p.name} · {formatNumber(p.solarDistance, 2)} AU من الشمس</title>{selected && <><circle r="17" fill={p.color} opacity=".055"/><path d="M-16-7v-9h9M7-16h9v9M16 7v9H7M-7 16h-9V7" stroke="var(--accent)" strokeWidth="1.2" fill="none"/></>}<circle r={['Jupiter', 'Saturn'].includes(p.id) ? 8.5 : ['Uranus', 'Neptune'].includes(p.id) ? 7 : 5.5} fill={`url(#dot-${p.id})`}/>{p.id === 'Saturn' && <ellipse rx="13" ry="3.5" fill="none" stroke={p.color} opacity=".68" transform="rotate(-25)"/>}<text x={left ? -22 : 22} y="-11" textAnchor={left ? 'end' : 'start'} className={`planet-label ${selected ? 'selected' : ''}`}>{p.name}</text>{selected && <text x={left ? -22 : 22} y="5" textAnchor={left ? 'end' : 'start'} className="distance-label">{formatNumber(p.solarDistance, 2)} AU</text>}</g>; })}
            {showComets && comets.slice(0, 3).map((c, i) => { const p = radarPoint(c.helio); return <g key={c.id} transform={`translate(${p.x} ${p.y})`}><path d="M-4 1l-19 13 14-17" fill="#a7d5cf" opacity=".2"/><circle r="3" fill="#b4dad4"/><text x="-10" y="22" textAnchor="end" className="comet-chart-label">{c.name.split(' ')[0]}</text></g>; })}
          </> : <>
            {[30, 60, 90].map(a => <g key={a}><circle cx={CX} cy={CY} r={a / 90 * SKY_R} fill="none" stroke="var(--orbit-line)" strokeDasharray={a === 90 ? 'none' : '3 5'}/><text x={CX + 8} y={CY - a / 90 * SKY_R + 13} className="sky-degree">{90 - a}°</text></g>)}
            <text x={CX} y={CY - SKY_R - 17} textAnchor="middle" className="cardinal">شمال · N</text><text x={CX + SKY_R + 23} y={CY + 4} className="cardinal">شرق · E</text><text x={CX} y={CY + SKY_R + 24} textAnchor="middle" className="cardinal">جنوب · S</text><text x={CX - SKY_R - 23} y={CY + 4} textAnchor="end" className="cardinal">غرب · W</text>
            {skyBodies.map(p => { const point = polarPoint(p); const selected = p.id === selectedId; return <g key={p.id} transform={`translate(${point.x} ${point.y})`} className="radar-object" role={PLANETS.some(v => v.id === p.id) ? 'button' : 'img'} tabIndex="0" onClick={() => PLANETS.some(v => v.id === p.id) && onSelect(p.id)} onKeyDown={e => e.key === 'Enter' && PLANETS.some(v => v.id === p.id) && onSelect(p.id)} aria-label={`${p.name} ارتفاع ${formatNumber(p.altitude)} درجة`}><title>{p.name} · ارتفاع {formatNumber(p.altitude)}° · سمت {formatNumber(p.azimuth)}°</title>{selected && <circle r="17" fill="none" stroke="var(--accent)" strokeWidth="1"/>}<circle r={p.id === 'Sun' ? 9 : 6} fill={p.color}/><text x="12" y="-9" className={`planet-label ${selected ? 'selected' : ''}`}>{p.name}</text></g>; })}
            <circle cx={CX} cy={CY} r="3" fill="var(--accent)"/><text x={CX + 8} y={CY + 16} className="distance-label">سمت الرأس</text>
          </>}
        </g>
      </svg>
      <div className="zoom-controls"><button aria-label="تقريب الخريطة" title="تقريب" onClick={() => setZoom(z => Math.min(2.5, z + .25))}><Plus size={16}/></button><button aria-label="إبعاد الخريطة" title="إبعاد" onClick={() => setZoom(z => Math.max(.65, z - .25))}><Minus size={16}/></button><button aria-label="إعادة ضبط الخريطة" title="إعادة ضبط" onClick={() => setZoom(1)}><RotateCcw size={14}/></button></div>
      {mode === 'solar' ? <button className={`comet-toggle ${showComets ? 'on' : ''}`} onClick={() => setShowComets(v => !v)}>{showComets ? <Eye size={13}/> : <EyeOff size={13}/>}المذنبات</button> : <span className="sky-note">{skyBodies.length} أجرام فوق الأفق · الرؤية ليست مضمونة</span>}
      <div className="diagram-note">{mode === 'solar' ? 'المواضع محسوبة · المسافات والأحجام مضغوطة بصريًا' : 'الارتفاع والسمت محسوبان للموقع المحدد · الانكسار الجوي تقريبي'}</div>
    </div>
    <div className="planet-legend">{PLANETS.map(p => <button className={p.id === selectedId ? 'selected' : ''} key={p.id} onClick={() => onSelect(p.id)}><i style={{ background: p.color }}/>{p.name}</button>)}</div>
    {controls && <div className="radar-controls">{controls}</div>}
  </section>;
}
